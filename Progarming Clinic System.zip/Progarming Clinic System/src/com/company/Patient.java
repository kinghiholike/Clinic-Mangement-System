package com.company;

public class Patient {
    public Patient(int i, String king, String king1, int i1, String kohomasdal_hofsanger_street, String tb) {
    }
}
