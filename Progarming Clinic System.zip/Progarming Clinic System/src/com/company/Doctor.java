package com.company;



public class Doctor {
    private int doctorID;
    private String doctorName;
    private String doctorSpecialist;
    private String doctorEmail;
    private String doctorMobile;


    public int getDoctorID() {
        return doctorID;
    }

    public void setDoctorID(int doctorID) {
        this.doctorID = doctorID;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getDoctorSpecialist() {
        return doctorSpecialist;
    }

    public void setDoctorSpecialist(String doctorSpecialist) {
        this.doctorSpecialist = doctorSpecialist;
    }

    public String getDoctorEmail() {
        return doctorEmail;
    }

    public void setDoctorEmail(String doctorEmail) {
        this.doctorEmail = doctorEmail;
    }

    public String getDoctorMobile() {
        return doctorMobile;
    }

    public void setDoctorMobile(String doctorMobile) {
        this.doctorMobile = doctorMobile;
    }

    @Override
    public String toString() {
        return "Doctor{" +
                "doctorID=" + doctorID +
                ", doctorName='" + doctorName + '\'' +
                ", doctorSpecialist='" + doctorSpecialist + '\'' +
                ", doctorEmail='" + doctorEmail + '\'' +
                ", doctorMobile=" + doctorMobile +
                '}';
    }

    public Doctor(int doctorID,String doctorName,String doctorSpecialist,String doctorEmail,String doctorMobile)
     {
         this.doctorID= doctorID ;
        this.doctorName = doctorName;
        this.doctorSpecialist = doctorSpecialist;
        this.doctorEmail = doctorEmail;
        this.doctorMobile = doctorMobile;

        this.doctorID = 0;
        this.doctorName = "";
        this.doctorSpecialist = "";
        this.doctorEmail = "";
        this.doctorMobile = "F";



    }
}





