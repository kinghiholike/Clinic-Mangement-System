package com.company;

public class Appointment {
    public Appointment(int i, Object fredrick, String s, String rip) {
    }
}
