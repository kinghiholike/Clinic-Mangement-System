package com.company;



public class Main {



    public static <Medication, Clinic> void main(String[] args) {


       Doctor  Doctor1 = new Doctor(111,  "Fredrick","TB","fredrick@gmail.com","1324");
       GeneralStationaries stationaries = new GeneralStationaries("Level1 ");
       Nurse nurse = new Nurse (11,"Anna","TB","456","anna","First floor");
       Patient patient = new  Patient(121,"King","king",122,"Kohomasdal Hofsanger street","TB");
        Object Fredrick = null;
        Appointment appointment = new Appointment(112,Fredrick,"12 Frebruary 2023","RIP");
        System.out.println(Doctor1);
        System.out.println(nurse);
        System.out.println(patient);
        System.out.println(appointment);
    }
}
