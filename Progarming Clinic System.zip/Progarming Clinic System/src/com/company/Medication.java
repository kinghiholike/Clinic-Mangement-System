package com.company;

public class Medication {
    private int medicineID;
    private String medicideName;
    private String medicideType;
    private String medicideCost;
    private String medicideDose;

    public Medication() {

    }

    public int getMedicineID() {
        return medicineID;
    }

    public void setMedicineID(int medicineID) {
        this.medicineID = medicineID;
    }

    public String getMedicideName() {
        return medicideName;
    }

    public void setMedicideName(String medicideName) {
        this.medicideName = medicideName;
    }

    public String getMedicideType() {
        return medicideType;
    }

    public void setMedicideType(String medicideType) {
        this.medicideType = medicideType;
    }

    public String getMedicideCost() {
        return medicideCost;
    }

    public void setMedicideCost(String medicideCost) {
        this.medicideCost = medicideCost;
    }

    public String getMedicideDose() {
        return medicideDose;
    }

    public void setMedicideDose(String medicideDose) {
        this.medicideDose = medicideDose;
    }

    public Medication(int medicineID, String medicideName, String medicideType, String medicideCost, String medicideDose) {
        this.medicineID = medicineID;
        this.medicideName = medicideName;
        this.medicideType = medicideType;
        this.medicideCost = medicideCost;
        this.medicideDose = medicideDose;
    }

    public void addMedicine() {

    }
    public void editMedicine() {

    }
    public void deleteMedicines() {

    }
    public void updateMedicines() {

    }
    public void searchMedicines() {

    }

    @Override
    public String toString() {
        return "Medication{" +
                "medicineID=" + medicineID +
                ", medicideName='" + medicideName + '\'' +
                ", medicideType='" + medicideType + '\'' +
                ", medicideCost='" + medicideCost + '\'' +
                ", medicideDose='" + medicideDose + '\'' +
                '}';
    }

    public void saveMedicines() {




    }
}


