package com.company;

public class Clinic {
    private int clinicID;
    private String clinicName;
    private String clinicAddress;

    public int getClinicID() {
        return clinicID;
    }

    public void setClinicID(int clinicID) {
        this.clinicID = clinicID;
    }

    public String getClinicName() {
        return clinicName;
    }

    public void setClinicName(String clinicName) {
        this.clinicName = clinicName;
    }

    public String getClinicAddress() {
        return clinicAddress;
    }

    public void setClinicAddress(String clinicAddress) {
        this.clinicAddress = clinicAddress;
    }

    public Clinic(int clinicID, String clinicName, String clinicAddress) {
        this.clinicID = clinicID;
        this.clinicName = clinicName;
        this.clinicAddress = clinicAddress;
    }

    public void addClinic() {

    }
    public void editClinic() {

    }

    @Override
    public String toString() {
        return "Clinic{" +
                "clinicID=" + clinicID +
                ", clinicName='" + clinicName + '\'' +
                ", clinicAddress='" + clinicAddress + '\'' +
                '}';




    }
}


