package com.company;

public class Nurse {
    public Nurse(int i, String anna, String tb, String s, String anna1, String first_floor) {
    }
}
