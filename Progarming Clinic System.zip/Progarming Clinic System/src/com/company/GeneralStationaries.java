package com.company;

public class GeneralStationaries {
    public GeneralStationaries(String level1_) {
    }
}
