public class Patient {
    private int patientID;
    private String patientName;
    private String patientSurname;
    private int patientMobile;
    private String patientAddress;
    private String patientDiagnosis;

    public Patient(){
        this.patientID = 0;
        this.patientName = "";
        this.patientSurname = "";
        this.patientMobile = 0;
        this.patientAddress = "";
        this.patientDiagnosis = "";

    }


    public int getPatientID() {
        return patientID;
    }

    public void setPatientID(int patientID) {
        this.patientID = patientID;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getPatientSurname() {
        return patientSurname;
    }

    public void setPatientSurname(String patientSurname) {
        this.patientSurname = patientSurname;
    }

    public int getPatientMobile() {
        return patientMobile;
    }

    public void setPatientMobile(int patientMobile) {
        this.patientMobile = patientMobile;
    }

    public String getPatientAddress() {
        return patientAddress;
    }

    public void setPatientAddress(String patientAddress) {
        this.patientAddress = patientAddress;
    }

    public String getPatientDiagnosis() {
        return patientDiagnosis;
    }

    public void setPatientDiagnosis(String patientDiagnosis) {
        this.patientDiagnosis = patientDiagnosis;
    }

    @Override
    public String toString() {
        return "Patient{" +
                "patientID=" + patientID +
                ", patientName='" + patientName + '\'' +
                ", patientSurname='" + patientSurname + '\'' +
                ", patientMobile=" + patientMobile +
                ", patientAddress='" + patientAddress + '\'' +
                ", patientDiagnosis='" + patientDiagnosis + '\'' +
                '}';
    }

    public Patient(int patientID, String patientName, String patientSurname, int patientMobile, String patientAddress, String patientDiagnosis) {








        this.patientID = patientID;
        this.patientName = patientName;
        this.patientSurname = patientSurname;
        this.patientMobile = patientMobile;
        this.patientAddress = patientAddress;
        this.patientDiagnosis = patientDiagnosis;



    }
}

