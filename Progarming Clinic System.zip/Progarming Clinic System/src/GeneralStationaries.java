

    public class GeneralStationaries {
        private String Storage;


        public String getStorage() {
            return Storage;
        }

        public void setStorage(String storage) {
            Storage = storage;
        }

        @Override
        public String toString() {
            return "GeneralStationaries{" +
                    "Storage='" + Storage + '\'' +
                    '}';
        }

        public GeneralStationaries(String Storage){

    this.Storage = Storage;

    this.Storage = "";


}
    }