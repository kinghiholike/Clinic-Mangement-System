public class Nurse {
    private int nurseID;
    private String nurseName;
    private String nurseDuty;
    private int nurseMobile;
    private String nurseUsername;
    private String nurseAddress;

    public int getNurseID() {
        return nurseID;
    }

    public void setNurseID(int nurseID) {
        this.nurseID = nurseID;
    }

    public String getNurseName() {
        return nurseName;
    }

    public void setNurseName(String nurseName) {
        this.nurseName = nurseName;
    }

    public String getNurseDuty() {
        return nurseDuty;
    }

    public void setNurseDuty(String nurseDuty) {
        this.nurseDuty = nurseDuty;
    }

    public int getNurseMobile() {
        return nurseMobile;
    }

    public void setNurseMobile(int nurseMobile) {
        this.nurseMobile = nurseMobile;
    }

    public String getNurseUsername() {
        return nurseUsername;
    }

    public void setNurseUsername(String nurseUsername) {
        this.nurseUsername = nurseUsername;
    }

    public String getNurseAddress() {
        return nurseAddress;
    }

    public void setNurseAddress(String nurseAddress) {
        this.nurseAddress = nurseAddress;
    }

    @Override
    public String toString() {
        return "Nurse{" +
                "nurseID=" + nurseID +
                ", nurseName='" + nurseName + '\'' +
                ", nurseDuty='" + nurseDuty + '\'' +
                ", nurseMobile=" + nurseMobile +
                ", nurseUsername='" + nurseUsername + '\'' +
                ", nurseAddress='" + nurseAddress + '\'' +
                '}';
    }

    public Nurse(int nurseID,String nurseName,String nurseDuty,int nurseMobile,String nurseUsername, String nurseAddress  ){
        this.nurseID = nurseID;
        this. nurseName= nurseName;
        this.nurseDuty = nurseDuty ;
        this.nurseMobile  =nurseMobile ;
        this.nurseUsername =nurseUsername ;
        this.nurseAddress =nurseAddress ;



        this.nurseID = 0;
        this. nurseName= "";
        this.nurseDuty = "" ;
        this.nurseMobile  =0 ;
        this.nurseUsername ="";
        this.nurseAddress ="";


    }
}
