public class Appointment {
    private int appointmentID;
    private String appointmentDoctor;
    private String appointmentDate;
    private String appointmentDescription;


    public int getAppointmentID() {
        return appointmentID;
    }

    public void setAppointmentID(int appointmentID) {
        this.appointmentID = appointmentID;
    }

    public String getAppointmentDoctor() {
        return appointmentDoctor;
    }

    public void setAppointmentDoctor(String appointmentDoctor) {
        this.appointmentDoctor = appointmentDoctor;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(String appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public String getAppointmentDescription() {
        return appointmentDescription;
    }

    public void setAppointmentDescription(String appointmentDescription) {
        this.appointmentDescription = appointmentDescription;
    }

    @Override
    public String toString() {
        return "Appointment{" +
                "appointmentID=" + appointmentID +
                ", appointmentDoctor='" + appointmentDoctor + '\'' +
                ", appointmentDate='" + appointmentDate + '\'' +
                ", appointmentDescription='" + appointmentDescription + '\'' +
                '}';
    }

    public Appointment(int appointmentID,String appointmentDoctor,String appointmentDate, String appointmentDescription){


    this.appointmentID = appointmentID;
    this.appointmentDoctor = appointmentDoctor;
    this.appointmentDate = appointmentDate;
    this.appointmentDescription = appointmentDescription;



    this.appointmentID=0;
    this.appointmentDoctor = "";
    this.appointmentDate = "";
    this.appointmentDescription = "";


}
}